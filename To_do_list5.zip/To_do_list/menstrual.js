document.addEventListener('DOMContentLoaded', () => {
    const menstrualForm = document.getElementById('menstrualForm');
    const resultDiv = document.getElementById('result');

    menstrualForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const lastPeriodDate = new Date(document.getElementById('lastPeriodDate').value);
        const cycleLength = parseInt(document.getElementById('cycleLength').value);
        const nextPeriodDate = new Date(lastPeriodDate);
        nextPeriodDate.setDate(nextPeriodDate.getDate() + cycleLength);
        const notificationDate = new Date(nextPeriodDate);
        notificationDate.setDate(notificationDate.getDate() - 3);

        const formattedNextPeriodDate = nextPeriodDate.toDateString();
        const formattedNotificationDate = notificationDate.toDateString();

        resultDiv.innerHTML = `
            <h3>Your next period is expected on:</h3>
            <p>${formattedNextPeriodDate}</p>
            <h3>You will be notified on:</h3>
            <p>${formattedNotificationDate}</p>
            <img src="360_F_71559544_EqSYpmfNStKoozBZ7Amne5cbZxj6yu12.jpg" alt="Period Image" class="result-image">
        `;
        resultDiv.style.display = 'block';

        // Schedule notification (this is just a simulation; actual notifications require server-side or service worker setup)
        scheduleNotification(notificationDate, formattedNextPeriodDate);
    });

    function scheduleNotification(notificationDate, nextPeriodDate) {
        const now = new Date();
        const timeUntilNotification = notificationDate - now;

        if (timeUntilNotification > 0) {
            setTimeout(() => {
                alert(`Reminder: Your next period is expected on ${nextPeriodDate}`);
            }, timeUntilNotification);
        }
    }
});
