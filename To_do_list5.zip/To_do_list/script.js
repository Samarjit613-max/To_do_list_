document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const addTaskForm = document.getElementById('addTaskForm');
    const logoutBtn = document.getElementById('logoutBtn');
    const darkModeToggle = document.getElementById('darkModeToggle');
    const taskList = document.getElementById('taskList');
    const addTaskBtn = document.getElementById('addTaskBtn');
    const allTasksBtn = document.getElementById('allTasksBtn');
    const allTasksContainer = document.getElementById('allTasksContainer');
    const menstrualCycleCheckerBtn = document.getElementById('menstrualCycleCheckerBtn');

    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            authenticateUser(username, password);
        });
    }

    if (addTaskForm) {
        addTaskForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const taskName = document.getElementById('taskName').value;
            const taskCategory = document.getElementById('taskCategory').value;
            const taskDate = document.getElementById('taskDate').value;
            const taskTime = document.getElementById('taskTime').value;
            addTask(taskName, taskCategory, taskDate, taskTime);
        });
    }

    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            logout();
        });
    }

    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            darkModeToggle.textContent = document.body.classList.contains('dark-mode') ? 'Switch to Light Mode' : 'Switch to Dark Mode';
        });
    }

    if (addTaskBtn) {
        addTaskBtn.addEventListener('click', () => {
            window.location.href = 'addtask.html';
        });
    }

 

    if (allTasksBtn) {
        allTasksBtn.addEventListener('click', () => {
            displayAllTasks();
        });
    }

    loadTasks();

    function authenticateUser(username, password) {
        fetch('user.json')
            .then(response => response.json())
            .then(users => {
                const user = users.find(u => u.username === username && u.password === password);
                if (user) {
                    localStorage.setItem('loggedInUser', username);
                    window.location.href = 'index.html';
                } else {
                    alert('Invalid username or password');
                }
            });
    }

    function addTask(name, category, date, time) {
        const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        const newTask = { id: Date.now(), name, category, date, time, username: localStorage.getItem('loggedInUser') };
        tasks.push(newTask);
        localStorage.setItem('tasks', JSON.stringify(tasks));
        window.location.href = 'index.html';
    }

    function loadTasks() {
        const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        const userTasks = tasks.filter(task => task.username === localStorage.getItem('loggedInUser'));
        taskList.innerHTML = '';
        userTasks.forEach(task => {
            const taskItem = document.createElement('div');
            taskItem.className = 'task-item';
            taskItem.innerHTML = `
                <div>
                    <strong>${task.name}</strong> - ${task.category}<br>
                    ${task.date} ${task.time}
                </div>
                <div>
                    <button class="btn btn-sm btn-primary" data-task-id="${task.id}" onclick="editTask(${task.id})">Edit</button>
                    <button class="btn btn-sm btn-danger" data-task-id="${task.id}" onclick="deleteTask(${task.id})">Delete</button>
                </div>
            `;
            taskList.appendChild(taskItem);
        });
    }

    function displayAllTasks() {
        const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        const userTasks = tasks.filter(task => task.username === localStorage.getItem('loggedInUser'));
        allTasksContainer.innerHTML = '';
        userTasks.forEach(task => {
            const taskItem = document.createElement('div');
            taskItem.className = 'task-item';
            taskItem.innerHTML = `
                <div>
                    <img src="notebook-420011.jpg">
                    <strong>${task.name}</strong> - ${task.category}<br>
                    ${task.date} ${task.time}
                </div>
            `;
            allTasksContainer.appendChild(taskItem);
        });
    }

    window.editTask = function(taskId) {
        const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        const task = tasks.find(t => t.id === taskId);
        if (task) {
            const taskName = prompt('Edit task name:', task.name);
            const taskCategory = prompt('Edit task category:', task.category);
            const taskDate = prompt('Edit task date:', task.date);
            const taskTime = prompt('Edit task time:', task.time);
            if (taskName !== null && taskCategory !== null && taskDate !== null && taskTime !== null) {
                task.name = taskName;
                task.category = taskCategory;
                task.date = taskDate;
                task.time = taskTime;
                localStorage.setItem('tasks', JSON.stringify(tasks));
                loadTasks();
            }
        }
    };

    window.deleteTask = function(taskId) {
        const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        const updatedTasks = tasks.filter(t => t.id !== taskId);
        localStorage.setItem('tasks', JSON.stringify(updatedTasks));
        loadTasks();
    };

    function logout() {
        localStorage.removeItem('loggedInUser');
        window.location.href = 'login.html';
    }
});


//slider
document.addEventListener('DOMContentLoaded', function() {
    var parent = document.querySelector('.splitview'),
        topPanel = parent.querySelector('.top'),
        handle = parent.querySelector('.handle'),
        skewHack = 0,
        delta = 0;

    // If the parent has .skewed class, set the skewHack var.
    if (parent.className.indexOf('skewed') != -1) {
        skewHack = 1000;
    }

    parent.addEventListener('mousemove', function(event) {
        // Get the delta between the mouse position and center point.
        delta = (event.clientX - window.innerWidth / 2) * 0.5;

        // Move the handle.
        handle.style.left = event.clientX + delta + 'px';

        // Adjust the top panel width.
        topPanel.style.width = event.clientX + skewHack + delta + 'px';
    });
});

